package com.uttara.phoneBook;

/*
 * This is a placeholder for all constants 
 * of the application.
 * It has only variables with fixed values that 
 * can be used throughout the application codebase.
 */
public interface Constants {

	String SUCCESS = "success";
}
